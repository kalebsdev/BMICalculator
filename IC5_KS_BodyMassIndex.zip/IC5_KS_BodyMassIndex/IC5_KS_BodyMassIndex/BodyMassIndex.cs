﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC5_KS_BodyMassIndex
{
    public partial class BMICalculatorForm : Form
    {
        public BMICalculatorForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            weightTextBox.Clear();
            heightTextBox.Clear();
            bMILabel.Text = "";
            categoryLabel.Text = "";
            weightTextBox.Focus();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //prep
            double weight;
            double height;
            double bMI;
            string category;

            //read
            weight = Convert.ToDouble(weightTextBox.Text);
            height = Convert.ToDouble(heightTextBox.Text);
           

            //calc
            bMI = (weight * 703) / (height * height);
            bMILabel.Text = bMI.ToString("N1");

            //if stat
            if (bMI < 18.5)
            {
                category = "Underweight";
            }
            else if (bMI < 25)
            {
                category = "Normal";
            }
            
             else if (bMI < 30)
	{
        category = "Overeweight";
	}
            else
            {
                category = "Obese";
            }
            categoryLabel.Text = category;

            weightTextBox.Focus();
            weightTextBox.SelectAll();
            }
        }
    }

